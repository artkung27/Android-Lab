package shobshared1.sharedkan;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class PostCategoryActivity extends AppCompatActivity {
    private Button FoodBtn,ProductBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_category);

        FoodBtn = (Button) findViewById(R.id.food);
        ProductBtn = (Button) findViewById(R.id.product);

        FoodBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent b = new Intent (PostCategoryActivity.this,PostActivity.class);
                startActivity(b);
            }
        });

        ProductBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent x = new Intent (PostCategoryActivity.this,ProductPostActivity.class);
                startActivity(x);
            }
        });
    }
}
