# Simple-Blog-App

#### Project for Google Firebase-Hackathon-Pune-India

<img src="Screenshots/1.png" width=320/>

<img src="Screenshots/2.png" width=320/>

<img src="Screenshots/3.png" width=320/>

<img src="Screenshots/4.png" width=320/>

<img src="Screenshots/5.png" width=320/>

<img src="Screenshots/6.png" width=320/>
