package art.labsqlite;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class DeleteActivity extends AppCompatActivity {
    private MyDbHelper myDataHelper;
    private ContentValues Val;
    private SQLiteDatabase sqliteMyDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete);

        this.setTitle("View and Delete data");
        final TextView txtTitle_show = (TextView) findViewById(R.id.txtTitleName);
        Intent intent = getIntent();
        final String txt_get_title = intent.getStringExtra("title");
        txtTitle_show.setText(txt_get_title);

        final Button Delete = (Button) findViewById(R.id.button2);
        Delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DeleteRow(txtTitle_show.getText().toString());

            }
        });
        final Button Back = (Button) findViewById(R.id.button3);
        Delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent x = new Intent(DeleteActivity.this, MainActivity.class);
                startActivity(x);

            }
        });
        Button updateData = (Button) findViewById(R.id.button4);
        updateData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent showPage = new Intent(DeleteActivity.this, UpdateActivity.class);
                showPage.putExtra("title", "" + txt_get_title + "");
                startActivity(showPage);
            }
        });


    }

    public long DeleteRow(String dataTitle) {
        try {

            myDataHelper = new MyDbHelper(this);
            ContentValues Val = new ContentValues();
            sqliteMyDB = myDataHelper.getWritableDatabase();
            long rows = sqliteMyDB.delete(myDataHelper.TABLE_NAME, "title=?", new String[]{String.valueOf(dataTitle)});
            sqliteMyDB.close();
            Toast.makeText(DeleteActivity.this, "Success!", Toast.LENGTH_SHORT).show();
            return rows;
        } catch (Exception e) {
            return -1;
        }
    }
}
